import type {Metadata} from 'next';
import { Inter, Outfit } from 'next/font/google';
import './globals.css'; // Global styles

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-sans',
  display: 'swap',
});

const outfit = Outfit({
  subsets: ['latin'],
  variable: '--font-display',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Growth Media Hub | Premium & Luxury Marketing Agency',
  description: 'Growth Media Hub helps ambitious brands dominate their market through cutting-edge social media marketing, high-converting advertising campaigns, premium content creation, and data-driven growth strategies.',
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${inter.variable} ${outfit.variable} scroll-smooth`}>
      <body className="font-sans antialiased bg-[#02050E] text-slate-100" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}

