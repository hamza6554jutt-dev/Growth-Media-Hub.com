'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, 
  Target, 
  Share2, 
  TrendingUp, 
  Video, 
  Crown, 
  Zap, 
  Briefcase, 
  CheckCircle2, 
  PhoneCall, 
  ArrowRight, 
  Menu, 
  X, 
  Layers, 
  Instagram, 
  Facebook, 
  MessageSquare, 
  Linkedin, 
  Award, 
  Compass, 
  Lightbulb, 
  Users, 
  Star, 
  Loader2, 
  Clock, 
  ChevronRight, 
  Play, 
  FileText,
  Mail,
  MapPin,
  Send,
  Sparkle,
  ArrowUp,
  ChevronDown,
  ChevronUp,
  ChevronLeft,
  MessageCircle
} from 'lucide-react';

// Portfolio Case Studies
// HIGH-FIDELITY BRAND GM LOGO COMPONENT
function GMBrandLogo({ className = "w-10 h-10", dark = true }: { className?: string; dark?: boolean }) {
  return (
    <svg 
      className={className} 
      viewBox="0 0 500 350" 
      fill="none" 
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        {/* Blue elements gradient: deep royal branding blue */}
        <linearGradient id="gmBlueGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={dark ? "#0052D4" : "#0A3B75"} />
          <stop offset="100%" stopColor={dark ? "#1E40AF" : "#1e3a5f"} />
        </linearGradient>
        
        {/* Sky-blue arrow gradient conforming to GM style guide */}
        <linearGradient id="gmArrowGrad" x1="0%" y1="100%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#0072BC" />
          <stop offset="100%" stopColor="#00ADEF" />
        </linearGradient>

        {/* Golden-orange bars gradient mapping the growth vector */}
        <linearGradient id="gmGoldGrad" x1="0%" y1="100%" x2="0%" y2="0%">
          <stop offset="0%" stopColor="#EA580C" />
          <stop offset="100%" stopColor="#FBBF24" />
        </linearGradient>
        
        {/* Gold border gradient for cards */}
        <linearGradient id="gmGoldBorder" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#F3E7C4" />
          <stop offset="50%" stopColor="#D8B44F" />
          <stop offset="100%" stopColor="#A37C24" />
        </linearGradient>
      </defs>

      {/* Monogram Group */}
      <g transform="translate(45, 10)">
        {/* G Outer Arc */}
        <path
          d="M 120,60 
             C 55,60 10,105 10,170 
             C 10,235 55,280 120,280 
             C 152,280 180,265 200,242 
             C 204,238 203,231 198,227 
             L 185,214 
             C 181,210 174,211 170,216 
             C 158,229 140,237 120,237 
             C 80,237 48,205 48,170 
             C 48,135 80,103 120,103 
             C 140,103 158,111 170,124 
             C 174,129 181,130 185,126 
             L 198,113 
             C 203,109 204,102 200,98 
             C 180,75 152,60 120,60 Z"
          fill="url(#gmBlueGrad)"
        />

        {/* Cradled Growth Bars inside G */}
        {/* Column 1 */}
        <path
          d="M 58,218 L 73,218 C 75,218 77,220 77,222 L 77,243 C 77,245 75,247 73,247 L 58,247 C 56,247 54,245 54,243 L 54,222 C 54,220 56,218 58,218 Z"
          fill="url(#gmGoldGrad)"
        />
        {/* Column 2 */}
        <path
          d="M 83,190 L 98,190 C 100,190 102,192 102,194 L 102,243 C 102,245 100,247 98,247 L 83,247 C 81,247 79,245 79,243 L 79,194 C 79,192 81,190 83,190 Z"
          fill="url(#gmGoldGrad)"
        />
        {/* Column 3 */}
        <path
          d="M 108,162 L 123,162 C 125,162 127,164 127,166 L 127,243 C 127,245 125,247 123,247 L 108,247 C 106,247 104,245 104,243 L 104,166 C 104,164 106,162 108,162 Z"
          fill="url(#gmGoldGrad)"
        />

        {/* Center horizontal connection bar block */}
        <path
          d="M 120,150 L 175,150 C 180,150 184,153 184,158 L 184,172 C 184,177 180,180 175,180 L 120,180 C 115,180 111,177 111,172 L 111,158 C 111,153 115,150 120,150 Z"
          fill="url(#gmBlueGrad)"
        />

        {/* Letter M joined to the horizontal plate */}
        <path
          d="M 184,165 
             L 230,165 
             C 233,165 235,167 236,170 
             L 260,225 
             L 282,170 C 283,167 285,165 288,165 
             L 345,165 
             C 351,165 354,171 351,176 
             L 310,265 
             C 308,270 301,270 299,265 
             L 260,195 
             L 221,265 C 219,270 212,270 210,265 
             L 179,176 
             C 176,171 179,165 184,165 Z"
          fill="url(#gmBlueGrad)"
        />

        {/* Dynamic sweeping arrow forming the right leg of M and sweeping up-right */}
        <path
          d="M 285,218 
             C 305,185 328,105 372,48"
          stroke="url(#gmArrowGrad)"
          strokeWidth="38"
          strokeLinecap="round"
        />
        {/* Arrow Head */}
        <path
          d="M 334,56 L 388,34 L 366,88 Z"
          fill="url(#gmArrowGrad)"
        />
      </g>
    </svg>
  );
}

// Portfolio Case Studies
interface CaseStudy {
  id: string;
  client: string;
  category: string;
  image: string;
  stats: string;
  metric: string;
  challenge: string;
  solution: string;
  result: string;
}

const caseStudies: CaseStudy[] = [
  {
    id: 'CS1',
    client: 'Aura Premium Cosmetics',
    category: 'Facebook & Instagram Advertising',
    image: 'https://picsum.photos/seed/aura/800/600',
    stats: '8.4x ROAS',
    metric: 'Meta Ad Scale-up',
    challenge: 'Aura needed to scale their luxury cosmetics skincare line beyond cold traffic stagnations and soaring customer acquisition costs.',
    solution: 'We crafted high-production-value video hooks focusing on texture and immediate application results, restructured their Meta pixel custom audiences, and deployed a value-optimized Lookalike funnel.',
    result: 'Achieved an average of 8.4x Return on Ad Spend over 90 days, generating $240k in first-purchase revenue and shrinking customer acquisition cost by 41%.'
  },
  {
    id: 'CS2',
    client: 'Vertu Elite Real Estate',
    category: 'Lead Generation Campaigns',
    image: 'https://picsum.photos/seed/vertu/800/600',
    stats: '$2.1M Pipeline',
    metric: 'High-Net-Worth Leads',
    challenge: 'Reaching premium ultra-high-net-worth buyers in regional real estate sectors without waste of ad spends.',
    solution: 'Built a highly interactive digital property valuation funnel, ran precision laser-targeted Facebook lead forms capturing verified telephone numbers, and implemented a premium automated SMS nurturing drip.',
    result: 'Captured over 340 pre-qualified regional buyer leads resulting in a calculated $2.1M close-value pipeline inside the client database in under 60 days.'
  },
  {
    id: 'CS3',
    client: 'Vanguard Enterprise SaaS',
    category: 'Content Strategy & SEO',
    image: 'https://picsum.photos/seed/vanguard/800/600',
    stats: '+340% Traffic',
    metric: 'Organic Scaling',
    challenge: 'Vanguard was spending heavily on PPC while search visibility of major software key phrases was non-existent.',
    solution: 'We deployed a topical authority hub clustering content around high-intent long-tail keywords, and distributed visually stunning premium educational carousel graphics and videos across LinkedIn.',
    result: 'Skyrocketed organic search impressions by 340%, leading to an inflow of 180+ monthly enterprise demo bookings strictly from search and social referrals.'
  }
];

// Blog Posts
interface BlogPost {
  title: string;
  excerpt: string;
  readTime: string;
  date: string;
  category: string;
  content: string;
}

const blogPosts: BlogPost[] = [
  {
    category: "Paid Acquisition",
    title: "The 2026 Direct-to-Consumer Funnel Architecture",
    excerpt: "Why traditional search and social funnels are failing, and how the modern hybrid algorithmic placement changes your scaling efforts.",
    readTime: "6 min read",
    date: "June 18, 2026",
    content: "In 2026, the traditional top-middle-bottom funnel is being completely replaced by unified algorithmic delivery matches. Platforms like Meta and TikTok now require highly specialized, broad-targeting creatives rather than micro-granular client segmentations. This dossier breaks down how we build self-optimizing creative assets that identify and guide qualified customers to checkout automatically, lowering acquisition cost by up to 35%."
  },
  {
    category: "Brand Development",
    title: "Commanding Premium Value: A Brand Strategy Guide",
    excerpt: "How to shift your product positioning from a commodity to a luxury asset using deliberate visual and typographic paradigms.",
    readTime: "8 min read",
    date: "June 12, 2026",
    content: "If your brand competes purely on price, it is commoditized and highly vulnerable. Elevating your brand perception to 'luxury status' relies on precise visual and typographic rhythms, generous negative spacing, custom high-contrast palettes, and human-sounding elite copywriting. Discover the steps we used at Growth Media Hub to double premium service prices for our luxury portfolio clients while simultaneously increasing conversion ratios."
  },
  {
    category: "Lead Generation",
    title: "Unlocking Facebook Ads ROAS in the Privacy-First Era",
    excerpt: "How first-party data capture is changing. Best practices to future-proof your advertising tracking systems today.",
    readTime: "5 min read",
    date: "June 05, 2026",
    content: "With ever-increasing mobile security features and cookies phasing out, ad networks have smaller windows for matching purchases. To win, brands must build resilient first-party data captures directly inside their landing channels. Integrating custom conversion APIs and offering high-value interactive lead magnets (like our AI strategy hub) allows you to feed deep intent markers back to the algorithmic ad engines."
  }
];

export default function Home() {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);
  const [successMsg, setSuccessMsg] = React.useState<string | null>(null);
  const [activeCaseStudy, setActiveCaseStudy] = React.useState<CaseStudy | null>(null);
  const [activeBlogPost, setActiveBlogPost] = React.useState<BlogPost | null>(null);

  // Custom added Premium states
  const [activeTestimonial, setActiveTestimonial] = React.useState(0);
  const [openedFaq, setOpenedFaq] = React.useState<number | null>(null);
  const [showScrollTop, setShowScrollTop] = React.useState(false);
  const [showWhatsappTooltip, setShowWhatsappTooltip] = React.useState(true);
  const [activeBeforeAfter, setActiveBeforeAfter] = React.useState(0);
  const [stats, setStats] = React.useState({ spend: 0, roas: 3.5, retention: 80, revenue: 0 });

  // Load animating metrics on mount
  React.useEffect(() => {
    const interval = setInterval(() => {
      setStats(prev => {
        const nextSpend = prev.spend < 12 ? prev.spend + 1 : 12;
        const nextRoas = prev.roas < 8.4 ? parseFloat((prev.roas + 0.5).toFixed(1)) : 8.4;
        const nextRetention = prev.retention < 98 ? prev.retention + 2 : 98;
        const nextRev = prev.revenue < 150 ? prev.revenue + 10 : 150;
        
        if (nextSpend === 12 && nextRoas === 8.4 && nextRetention === 98 && nextRev === 150) {
          clearInterval(interval);
        }
        return { spend: nextSpend, roas: nextRoas, retention: nextRetention, revenue: nextRev };
      });
    }, 85);
    return () => clearInterval(interval);
  }, []);

  // Track scroll position for scroll-to-top feature
  React.useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 500) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Consult Form Input State
  const [consultName, setConsultName] = React.useState('');
  const [consultEmail, setConsultEmail] = React.useState('');
  const [consultPhone, setConsultPhone] = React.useState('');
  const [consultBusiness, setConsultBusiness] = React.useState('');
  const [consultPlatform, setConsultPlatform] = React.useState('Meta Ads (FB/IG)');
  const [consultMsg, setConsultMsg] = React.useState('');
  const [formLoading, setFormLoading] = React.useState(false);

  // AI Strategy Generator State
  const [strategyBusiness, setStrategyBusiness] = React.useState('');
  const [strategyIndustry, setStrategyIndustry] = React.useState('');
  const [strategyChannel, setStrategyChannel] = React.useState('Instagram Mastery');
  const [strategyTone, setStrategyTone] = React.useState('Luxury & Elite');
  const [strategyBudget, setStrategyBudget] = React.useState('$2,000 - $5,000 / mo');

  const [aiGenerating, setAiGenerating] = React.useState(false);
  const [aiResult, setAiResult] = React.useState<string | null>(null);
  const [aiError, setAiError] = React.useState<string | null>(null);
  const [aiGenStep, setAiGenStep] = React.useState('');

  const scrollSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const headerOffset = 90; // offset for sticky header
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;
      
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  // Handle consultation form submission
  const handleConsultSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!consultName || !consultEmail || !consultPhone || !consultBusiness) {
      alert("Please fill in all required fields to register your session.");
      return;
    }

    setFormLoading(true);
    // Simulate luxury API network request
    await new Promise(resolve => setTimeout(resolve, 1500));
    setFormLoading(false);
    
    setSuccessMsg(`Thank you, ${consultName}! Your Elite Consultation slot at Growth Media Hub has been pre-reserved. An executive growth strategist will review your business information and reach out within 2 hours.`);
    
    // Reset Form
    setConsultName('');
    setConsultEmail('');
    setConsultPhone('');
    setConsultBusiness('');
    setConsultMsg('');
  };

  // Generate Strategy with Gemini API Route
  const generateStrategy = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!strategyBusiness || !strategyIndustry) {
      setAiError("Please supply your Business Name and Industry/Niche to continue.");
      return;
    }

    setAiGenerating(true);
    setAiError(null);
    setAiResult(null);

    // Dynamic state messages to excite the user while Gemini generates
    const generationSteps = [
      "Analyzing market trends for your niche...",
      "Scouring successful campaign indicators in our vault...",
      "Formulating bespoke audience targeting funnels...",
      "Drafting elegant visual & content hooks...",
      "Structuring precision performance ROAS projection models...",
      "Polishing executive summary dossier..."
    ];

    let stepIndex = 0;
    setAiGenStep(generationSteps[0]);

    const intervalId = setInterval(() => {
      stepIndex++;
      if (stepIndex < generationSteps.length) {
        setAiGenStep(generationSteps[stepIndex]);
      }
    }, 2800);

    try {
      const response = await fetch("/api/gemini/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          businessName: strategyBusiness,
          industry: strategyIndustry,
          budget: strategyBudget,
          primaryChannel: strategyChannel,
          brandTone: strategyTone
        })
      });

      const data = await response.json();
      clearInterval(intervalId);

      if (!response.ok) {
        throw new Error(data.error || "Generation engine returned error status.");
      }

      setAiResult(data.text);
    } catch (err: any) {
      clearInterval(intervalId);
      console.error(err);
      setAiError(err.message || "Bespoke strategy engine encountered an unexpected validation check. Please consult our human agents.");
    } finally {
      setAiGenerating(false);
    }
  };

  // Custom luxury markdown renderer for beautiful display
  const renderStrategyMarkdown = (text: string) => {
    if (!text) return null;
    
    const lines = text.split('\n');
    let output: React.ReactNode[] = [];
    let listItems: string[] = [];

    lines.forEach((line, index) => {
      // Headers
      if (line.startsWith('###') || line.startsWith('##')) {
        // Flush any accumulated list items first
        if (listItems.length > 0) {
          const listToPush = (
            <ul key={`list-${index}`} className="space-y-3 my-6 animate-fade-in pl-1">
              {listItems.map((li, i) => (
                <li key={`li-${index}-${i}`} className="flex items-start text-sm text-slate-300 leading-relaxed">
                  <span className="text-[#D8B44F] font-bold mr-3 mt-0.5 font-sans">✓</span>
                  <span>{li}</span>
                </li>
              ))}
            </ul>
          );
          output.push(listToPush);
          listItems = [];
        }

        const headingText = line.replace(/^###?\s+/, '');
        output.push(
          <h4 key={`h-${index}`} className="text-xl font-display font-medium text-gold-gradient tracking-wide mt-8 mb-4 border-b border-gold/10 pb-2 flex items-center gap-2">
            <span className="w-1.5 h-6 bg-[#D8B44F] rounded-full inline-block"></span>
            {headingText}
          </h4>
        );
      } 
      // Bullet points
      else if (line.startsWith('- ') || line.startsWith('* ')) {
        const itemText = line.replace(/^[-*]\s+/, '').replace(/\*\*(.*?)\*\*/g, '$1');
        listItems.push(itemText);
      } 
      // Empty spaces
      else if (line.trim() === '') {
        if (listItems.length > 0) {
          const listToPush = (
            <ul key={`list-${index}`} className="space-y-3 my-4 animate-fade-in pl-1">
              {listItems.map((li, i) => (
                <li key={`li-${index}-${i}`} className="flex items-start text-sm text-slate-300 leading-relaxed">
                  <span className="text-[#D8B44F] font-bold mr-3 mt-0.5 font-sans text-xs">✓</span>
                  <span>{li}</span>
                </li>
              ))}
            </ul>
          );
          output.push(listToPush);
          listItems = [];
        }
      } 
      // Standard Paragraph
      else {
        // Flush any lists
        if (listItems.length > 0) {
          const listToPush = (
            <ul key={`list-${index}`} className="space-y-3 my-4 animate-fade-in pl-1">
              {listItems.map((li, i) => (
                <li key={`li-${index}-${i}`} className="flex items-start text-sm text-slate-300 leading-relaxed">
                  <span className="text-[#D8B44F] font-bold mr-3 mt-0.5 font-sans text-xs">✓</span>
                  <span>{li}</span>
                </li>
              ))}
            </ul>
          );
          output.push(listToPush);
          listItems = [];
        }

        // Bold formatting parse helper
        let formattedLine: React.ReactNode = line;
        if (line.includes('**')) {
          const parts = line.split('**');
          formattedLine = parts.map((part, pIdx) => {
            if (pIdx % 2 === 1) {
              return <strong key={pIdx} className="text-[#F3E7C4] font-semibold font-sans">{part}</strong>;
            }
            return part;
          });
        }

        output.push(
          <p key={`p-${index}`} className="text-sm text-slate-300 leading-relaxed font-sans mb-3 font-normal opacity-90">
            {formattedLine}
          </p>
        );
      }
    });

    // Flush any remaining list items
    if (listItems.length > 0) {
      output.push(
        <ul key="list-final" className="space-y-3 my-4 animate-fade-in pl-1">
          {listItems.map((li, i) => (
            <li key={`li-final-${i}`} className="flex items-start text-sm text-slate-300 leading-relaxed">
              <span className="text-[#D8B44F] font-bold mr-3 mt-0.5 font-sans text-xs">✓</span>
              <span>{li}</span>
            </li>
          ))}
        </ul>
      );
    }

    return output;
  };

  return (
    <div className="min-h-screen relative overflow-x-hidden pt-20 flex flex-col justify-between">
      {/* Elegantly soft radial glares for premium dark ambiance */}
      <div className="absolute top-0 left-1/4 w-[500px] h-[500px] bg-blue-900/10 rounded-full blur-[140px] pointer-events-none -z-10" />
      <div className="absolute top-[40%] right-1/4 w-[600px] h-[600px] bg-[#D8B44F]/5 rounded-full blur-[160px] pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-1/3 w-[500px] h-[500px] bg-blue-950/15 rounded-full blur-[130px] pointer-events-none -z-10" />

      {/* LUXURY NAVBAR */}
      <header className="fixed top-0 left-0 right-0 h-20 bg-[#02050E]/90 backdrop-blur-md border-b border-[#D8B44F]/10 z-50 transition-all duration-300">
        <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          
          {/* Brand Logo with Customizable Monogram */}
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => scrollSection('hero')}>
            <div className="relative flex items-center justify-center w-12 h-12 bg-[#010515]/90 border border-[#D8B44F]/25 rounded hover:border-[#D8B44F]/50 transition-all shadow-inner overflow-hidden">
              <GMBrandLogo className="w-full h-full text-white" dark={true} />
              <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-[#D8B44F]/5 to-transparent pointer-events-none" />
            </div>
            <div className="flex flex-col">
              <h1 className="font-display font-bold text-base sm:text-lg leading-tight tracking-wider text-white select-none">
                GROWTH<span className="text-gold-gradient font-extrabold"> MEDIA</span>
              </h1>
              <div className="flex items-center gap-1.5 lines-container">
                <span className="h-[1px] w-3 bg-[#D8B44F]/40"></span>
                <span className="text-[8px] font-semibold uppercase tracking-[0.3em] text-[#D8B44F] font-mono leading-none">Hub</span>
                <span className="h-[1px] w-3 bg-[#D8B44F]/40"></span>
              </div>
            </div>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-6 xl:gap-8 text-[12px] xl:text-[13px] tracking-widest uppercase font-display font-medium text-slate-300">
            <button onClick={() => scrollSection('hero')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">Home</button>
            <button onClick={() => scrollSection('about')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">About Us</button>
            <button onClick={() => scrollSection('services')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">Services</button>
            <button onClick={() => scrollSection('portfolio')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">Portfolio</button>
            <button onClick={() => scrollSection('testimonials')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">Testimonials</button>
            <button onClick={() => scrollSection('ai-hub')} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-[#D8B44F] font-bold flex items-center gap-1">
              <Sparkles className="w-3.5 h-3.5" /> AI Hub
            </button>
            <button onClick={() => scrollSection('blog')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">Blog</button>
            <button onClick={() => scrollSection('contact')} className="hover:text-[#D8B44F] transition-colors focus:outline-none">Contact</button>
          </nav>

          {/* Consultation Lead Action Button */}
          <div className="hidden lg:block">
            <button 
              onClick={() => scrollSection('contact')}
              className="px-5 py-2.5 bg-gradient-to-r from-[#A37C24] via-[#D8B44F] to-[#A37C24] text-black font-semibold text-xs uppercase tracking-widest hover:brightness-110 active:scale-95 transition-all shadow-lg hover:shadow-[#D8B44F]/20 cursor-pointer"
            >
              Consult Free
            </button>
          </div>

          {/* Mobile Menu Toggle */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)} 
            className="lg:hidden text-white p-3 rounded-full hover:text-[#D8B44F] focus:outline-none bg-slate-900/50 border border-slate-800 flex items-center justify-center"
            aria-label="Toggle Menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {mobileMenuOpen && (
            <motion.div 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="lg:hidden absolute top-20 left-0 right-0 bg-[#02050E]/98 border-b border-[#D8B44F]/25 shadow-2xl overflow-y-auto max-h-[85vh] py-6 z-40 backdrop-blur-xl"
            >
              <div className="flex flex-col gap-3 px-6 font-display font-semibold text-xs tracking-widest uppercase">
                <button onClick={() => scrollSection('hero')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">Home</button>
                <button onClick={() => scrollSection('about')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">About Us</button>
                <button onClick={() => scrollSection('services')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">Services</button>
                <button onClick={() => scrollSection('portfolio')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">Portfolio</button>
                <button onClick={() => scrollSection('testimonials')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">Testimonials</button>
                <button onClick={() => scrollSection('ai-hub')} className="text-left py-3.5 px-4 bg-[#101F4E]/40 rounded border border-[#D8B44F]/20 text-[#D8B44F] font-bold flex items-center gap-1.5 transition-all">
                  <Sparkles className="w-4 h-4 animate-pulse" /> AI Strategy Hub
                </button>
                <button onClick={() => scrollSection('blog')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">Blog</button>
                <button onClick={() => scrollSection('contact')} className="text-left py-3.5 px-4 bg-slate-900/30 rounded border border-slate-800/60 hover:text-[#D8B44F] hover:border-[#D8B44F]/20 transition-all">Contact Us</button>
                
                <button 
                  onClick={() => scrollSection('contact')}
                  className="w-full text-center py-4 bg-gold-gradient text-black font-extrabold text-sm uppercase tracking-widest mt-4 hover:opacity-95 shadow-lg active:scale-95 transition-all rounded"
                >
                  Book Free Consultation
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      <main className="flex-grow">
        
        {/* HERO SECTION */}
        <section id="hero" className="relative min-h-[92vh] flex items-center py-16 px-6 lg:px-12">
          <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Copywriting & CTAs */}
            <div className="lg:col-span-7 flex flex-col justify-center text-left">
              
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#101935] border border-[#D8B44F]/30 rounded-full w-fit mb-6 animate-fade-in">
                <Sparkle className="w-3.5 h-3.5 text-[#D8B44F] animate-spin" style={{ animationDuration: '6s' }} />
                <span className="text-[10px] tracking-widest uppercase text-slate-200 font-mono font-bold">
                  TRANSFORMING BRANDS INTO MARKET LEADERS
                </span>
              </div>

              <h1 className="font-display font-medium text-4xl sm:text-5xl lg:text-6xl text-white tracking-tight leading-[1.05] mb-6">
                Transform Your Brand Into <span className="text-gold-gradient text-luxury-glow">a Market Leader</span>
              </h1>

              <p className="text-slate-300 font-sans text-base sm:text-lg leading-relaxed max-w-xl mb-8 opacity-95">
                We help businesses grow faster through powerful social media marketing, digital advertising, content creation, and lead generation strategies. Let Growth Media Hub turn attention into customers.
              </p>

              <div className="flex flex-col sm:flex-row gap-4">
                <button 
                  onClick={() => scrollSection('contact')}
                  className="px-8 py-4 bg-gradient-to-r from-[#A37C24] via-[#D8B44F] to-[#A37C24] text-black font-semibold text-sm rounded shadow-lg hover:shadow-[#D8B44F]/20 hover:scale-102 hover:brightness-110 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <PhoneCall className="w-4 h-4" />
                  Book Free Consultation
                </button>

                <button 
                  onClick={() => scrollSection('ai-hub')}
                  className="px-8 py-4 bg-[#070F2B] border border-[#D8B44F]/20 text-white font-semibold text-sm rounded hover:bg-[#0E1B46] hover:border-[#D8B44F]/40 hover:scale-102 active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-[#D8B44F]" />
                  Generate Free Strategy Blueprint
                </button>
              </div>

              {/* Quick confidence points */}
              <div className="grid grid-cols-2 gap-4 border-t border-[#D8B44F]/10 pt-10 mt-10">
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#D8B44F] shrink-0" />
                  <span className="text-xs uppercase tracking-wider text-slate-300 font-mono">Premium Custom Models</span>
                </div>
                <div className="flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-[#D8B44F] shrink-0" />
                  <span className="text-xs uppercase tracking-wider text-slate-300 font-mono">Guaranteed Transparency</span>
                </div>
              </div>

            </div>

            {/* Premium Interactive Showcase Widget */}
            <div className="lg:col-span-5 relative w-full flex justify-center">
              <div className="w-full max-w-md bg-[#070F2D]/80 border border-[#D8B44F]/20 p-6 rounded shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-[3px] bg-gold-gradient" />
                
                {/* Simulated Campaign Performance Metrics Dashboard -- Architecture Honesty & High-Quality Design */}
                <div className="flex justify-between items-center mb-6">
                  <div>
                    <h3 className="font-display font-semibold text-sm text-slate-200">Aura Campaigns Vault</h3>
                    <p className="text-[9px] text-[#D8B44F] font-mono tracking-widest uppercase">Verified Real-Time Metric Insights</p>
                  </div>
                  <span className="px-2 py-0.5 bg-green-500/10 text-green-400 border border-green-500/20 text-[9px] rounded font-mono font-bold animate-pulse">
                    ● ACTIVE SCALE
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-6">
                  <div className="bg-[#02050E] p-3 rounded border border-slate-800">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Scale Return</p>
                    <p className="text-2xl font-display font-bold text-white tracking-tight">8.4x <span className="text-[#D8B44F] text-xs font-semibold">ROAS</span></p>
                  </div>
                  <div className="bg-[#02050E] p-3 rounded border border-slate-800">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Impression Boost</p>
                    <p className="text-2xl font-display font-bold text-white tracking-tight">+3.4M</p>
                  </div>
                </div>

                {/* Growth Curve */}
                <div className="bg-[#02050E] p-4 rounded border border-slate-800 mb-6">
                  <div className="flex justify-between items-end h-[100px] gap-2 pt-4">
                    <div className="w-full bg-slate-800 rounded-t h-[20%] transition-all duration-1000 origin-bottom" style={{ height: '20%' }} />
                    <div className="w-full bg-slate-800 rounded-t h-[35%] transition-all duration-1000 origin-bottom" style={{ height: '35%' }} />
                    <div className="w-full bg-blue-900/60 rounded-t h-[50%] transition-all duration-1000 origin-bottom animate-pulse" />
                    <div className="w-full bg-blue-800/80 rounded-t h-[65%] transition-all duration-1000" style={{ height: '65%' }} />
                    <div className="w-full bg-[#D8B44F]/50 rounded-t h-[80%] transition-all duration-1000" style={{ height: '80%' }} />
                    <div className="w-full bg-[#D8B44F] rounded-t h-[98%] shadow-[0_0_15px_rgba(216,180,79,0.3)] transition-all duration-1000" style={{ height: '98%' }} />
                  </div>
                  <div className="flex justify-between mt-2 text-[9px] text-slate-500 font-mono">
                    <span>Wk 1</span>
                    <span>Wk 4</span>
                    <span>Wk 8</span>
                    <span>Wk 12 (Launch Peak)</span>
                  </div>
                </div>

                {/* Conversion Trigger Box */}
                <div className="p-3 bg-gradient-to-r from-[#030A1F] to-[#0D1B46] border-l-2 border-[#D8B44F] text-xs text-slate-300">
                  <span className="font-semibold text-white">Scale Strategy:</span> Dynamic creatives paired with broad audience mapping instantly bypass high cost-per-lead limits. Let us configure this for your company.
                </div>
              </div>
            </div>

          </div>
        </section>

        {/* PREMIUM STATS COUNTER & TRUST BADGES SECTION */}
        <section className="bg-gradient-to-b from-[#02050E] to-[#040C24] py-16 border-t border-b border-[#D8B44F]/10 px-6 relative">
          
          {/* Subtly premium golden background decorative frame */}
          <div className="absolute inset-0 bg-[#D8B44F]/[0.01]" />

          <div className="max-w-7xl mx-auto relative z-10">
            
            {/* World-Class Certifications / Trust Badges Bar */}
            <div className="mb-14 text-center">
              <span className="text-[10px] uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-6">
                CERTIFIED AGENCY ACCOLADES
              </span>
              <div className="flex flex-wrap justify-center items-center gap-6 md:gap-14 text-[10px] uppercase font-mono tracking-widest text-slate-400">
                <div className="flex items-center gap-2 px-3 py-1.5 bg-[#061130] border border-[#D8B44F]/20 rounded">
                  <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse" />
                  <span>Meta Business Partner</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-[#061130] border border-[#D8B44F]/20 rounded">
                  <span className="w-1.5 h-1.5 bg-blue-500 rounded-full animate-pulse" />
                  <span>Google Premier Partner</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-[#061130] border border-[#D8B44F]/20 rounded">
                  <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse" />
                  <span>Shopify Expert Agency</span>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 bg-[#061130] border border-[#D8B44F]/20 rounded">
                  <span className="w-1.5 h-1.5 bg-[#D8B44F] rounded-full animate-pulse" />
                  <span>Forbes Agency Council</span>
                </div>
              </div>
            </div>

            {/* High-Impact Animated Statistics Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8 mb-14 text-center">
              <div className="bg-[#050D24]/40 border border-slate-800 hover:border-[#D8B44F]/25 p-5 md:p-8 rounded transition-all group">
                <p className="text-[10px] md:text-xs text-slate-500 uppercase tracking-widest font-mono mb-2">Budget Managed</p>
                <p className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight group-hover:text-gold-gradient transition-colors">
                  ${stats.spend}M+
                </p>
                <span className="text-[9px] uppercase tracking-wider text-[#D8B44F] font-mono mt-1 block">Paid Ad Networks</span>
              </div>
              
              <div className="bg-[#050D24]/40 border border-slate-800 hover:border-[#D8B44F]/25 p-5 md:p-8 rounded transition-all group">
                <p className="text-[10px] md:text-xs text-slate-500 uppercase tracking-widest font-mono mb-2">Campaign Yield</p>
                <p className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight group-hover:text-gold-gradient transition-colors">
                  {stats.roas}x
                </p>
                <span className="text-[9px] uppercase tracking-wider text-[#D8B44F] font-mono mt-1 block">Average ROAS</span>
              </div>

              <div className="bg-[#050D24]/40 border border-slate-800 hover:border-[#D8B44F]/25 p-5 md:p-8 rounded transition-all group">
                <p className="text-[10px] md:text-xs text-slate-500 uppercase tracking-widest font-mono mb-2">Niche Experience</p>
                <p className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight group-hover:text-gold-gradient transition-colors">
                  {stats.retention}%
                </p>
                <span className="text-[9px] uppercase tracking-wider text-[#D8B44F] font-mono mt-1 block">Retainer Retention</span>
              </div>

              <div className="bg-[#050D24]/40 border border-slate-800 hover:border-[#D8B44F]/25 p-5 md:p-8 rounded transition-all group">
                <p className="text-[10px] md:text-xs text-slate-500 uppercase tracking-widest font-mono mb-2">Earned Client Rev</p>
                <p className="text-3xl md:text-5xl font-display font-bold text-white tracking-tight group-hover:text-gold-gradient transition-colors">
                  ${stats.revenue}M+
                </p>
                <span className="text-[9px] uppercase tracking-wider text-[#D8B44F] font-mono mt-1 block">Client Revenue Generated</span>
              </div>
            </div>

            {/* Brands Carousel (Responsive, cleanly spaced) */}
            <div>
              <p className="text-center font-display font-medium text-[9px] tracking-[0.25em] text-slate-500 uppercase mb-6">
                ELITE MARKET LEADERS WHO TRUST OUR PARADIGMS
              </p>
              <div className="flex flex-wrap justify-center items-center gap-8 md:gap-16 opacity-60">
                <span className="font-display font-bold text-xs sm:text-base text-slate-400 tracking-widest hover:text-[#D8B44F] cursor-default transition-colors">AURA COSMETICS</span>
                <span className="font-display font-bold text-xs sm:text-base text-slate-400 tracking-widest hover:text-[#D8B44F] cursor-default transition-colors">VERTU GLOBAL</span>
                <span className="font-display font-bold text-xs sm:text-base text-slate-400 tracking-widest hover:text-[#D8B44F] cursor-default transition-colors">LUNA LIFESTYLE</span>
                <span className="font-display font-bold text-xs sm:text-base text-slate-400 tracking-widest hover:text-[#D8B44F] cursor-default transition-colors">ESTATE ELEVATE</span>
                <span className="font-display font-bold text-xs sm:text-base text-slate-400 tracking-widest hover:text-[#D8B44F] cursor-default transition-colors">VANGUARD CORP</span>
              </div>
            </div>

          </div>
        </section>

        {/* SERVICES SECTION */}
        <section id="services" className="py-24 px-6 lg:px-12 bg-[#02050E]">
          <div className="max-w-7xl mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">OUR CAPABILITIES</span>
              <h2 className="text-3xl sm:text-4xl font-display font-semibold text-white mb-4">
                Elite Marketing Services to Dominate Your Niche
              </h2>
              <div className="w-16 h-0.5 bg-gradient-to-r from-[#D8B44F] to-[#A37C24] mx-auto mt-4" />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              
              {/* Service Cards */}
              {[
                {
                  title: "Social Media Marketing",
                  desc: "Dominate search and organic screens with continuous modern community structures that drive brand loyalty.",
                  icon: <Share2 className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Facebook & Instagram Advertising",
                  desc: "High-yield paid acquisition strategies focused strictly on sales conversion, lead volume, and high ROAS.",
                  icon: <Sparkles className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Content Strategy & Creation",
                  desc: "Stunning aesthetic multimedia productions, copy, design templates, and viral short-form frameworks.",
                  icon: <Video className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Brand Development",
                  desc: "Elevate your perception, refine typography pairings, and establish luxury guidelines that justify top-tier premiums.",
                  icon: <Crown className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Lead Generation Campaigns",
                  desc: "Gather highly qualified premium buyer databases with direct phone callbacks, SMS automation, and email funnels.",
                  icon: <Target className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Search Engine Optimization (SEO)",
                  desc: "Capture high-intent searches. Scale authority clusters to secure permanent search real estate on massive phrases.",
                  icon: <TrendingUp className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Marketing Automation",
                  desc: "Build self-operating buyer flows, dynamic integrations, CRM follow-up systems, and automated email drips.",
                  icon: <Zap className="w-6 h-6 text-[#D8B44F]" />
                },
                {
                  title: "Business Growth Consulting",
                  desc: "High-level strategic analysis, competitive positioning strategies, and full unit economics review.",
                  icon: <Briefcase className="w-6 h-6 text-[#D8B44F]" />
                }
              ].map((service, idx) => (
                <div 
                  key={idx}
                  className="bg-[#050D24]/50 border border-slate-800 hover:border-[#D8B44F]/40 p-6 rounded relative overflow-hidden transition-all duration-300 group hover:translate-y-[-4px]"
                >
                  <div className="w-12 h-12 bg-blue-950/80 border border-slate-800 rounded flex items-center justify-center mb-5 group-hover:border-[#D8B44F]/40 transition-colors">
                    {service.icon}
                  </div>
                  <h3 className="font-display font-medium text-lg text-white mb-3 tracking-wide">{service.title}</h3>
                  <p className="text-slate-400 text-xs sm:text-sm leading-relaxed mb-4">{service.desc}</p>
                  
                  <button 
                    onClick={() => {
                      setStrategyChannel(service.title);
                      scrollSection('ai-hub');
                    }}
                    className="text-xs text-[#D8B44F] font-mono tracking-widest uppercase flex items-center gap-1.5 focus:outline-none hover:translate-x-1 transition-all mt-auto"
                  >
                    Test on AI Strategy <ChevronRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

            </div>
          </div>
        </section>

        {/* AI STRATEGY BLUEPRINT GENERATOR - HIGHEST CONVERTING INTERACTIVE UTILITY */}
        <section id="ai-hub" className="py-24 px-6 lg:px-12 bg-gradient-to-b from-[#02050E] to-[#040C24] border-t border-[#D8B44F]/10">
          <div className="max-w-7xl mx-auto">
            
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              
              {/* Form Input Side */}
              <div className="lg:col-span-5">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-[#101935] border border-[#D8B44F]/30 rounded-full w-fit mb-6">
                  <Sparkles className="w-3.5 h-3.5 text-[#D8B44F] animate-pulse" />
                  <span className="text-[10px] tracking-widest uppercase text-[#D8B44F] font-mono font-bold">
                    EXCLUSIVE LEAD ELEVATOR
                  </span>
                </div>

                <h2 className="text-3xl sm:text-4xl font-display font-semibold text-white tracking-tight leading-tight mb-4">
                  Generate Your Complimentary bespoke <span className="text-gold-gradient">Marketing Blueprint</span>
                </h2>
                
                <p className="text-slate-300 font-sans text-sm sm:text-base leading-relaxed mb-8">
                  Empower your brand with instant data-driven concepts. Specify your niche details, brand positioning theme, and channels, and our Gemini-powered strategizing matrix will formulate your customized blueprint roadmap within seconds.
                </p>

                <form onSubmit={generateStrategy} className="space-y-4 bg-[#050B1C] border border-[#D8B44F]/10 p-6 rounded shadow-lg">
                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Business Name *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Aura Aesthetics, Stellar Tech Cafe"
                      value={strategyBusiness}
                      onChange={(e) => setStrategyBusiness(e.target.value)}
                      className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none placeholder-slate-600 rounded"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Industry Or Niche *</label>
                    <input 
                      type="text" 
                      required
                      placeholder="e.g. Luxury Skincare, High-end Real Estate, B2B SaaS"
                      value={strategyIndustry}
                      onChange={(e) => setStrategyIndustry(e.target.value)}
                      className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none placeholder-slate-600 rounded"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[11px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Platform Focus</label>
                      <select 
                        value={strategyChannel}
                        onChange={(e) => setStrategyChannel(e.target.value)}
                        className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-xs text-white focus:outline-none rounded"
                      >
                        <option>Instagram Mastery</option>
                        <option>Facebook Ads Leads</option>
                        <option>DTC Meta Conversions</option>
                        <option>TikTok Short Form Scale</option>
                        <option>SEO Topical Domination</option>
                        <option>B2B LinkedIn Omnipresence</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[11px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Brand Persona</label>
                      <select 
                        value={strategyTone}
                        onChange={(e) => setStrategyTone(e.target.value)}
                        className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-xs text-white focus:outline-none rounded"
                      >
                        <option>Luxury & Elite</option>
                        <option>Aggressive Growth</option>
                        <option>Warm & Relatable</option>
                        <option>Sleek & Tech-First</option>
                        <option>Bold, Young & Trendy</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Dedicated Growth Ad Budget</label>
                    <select 
                      value={strategyBudget}
                      onChange={(e) => setStrategyBudget(e.target.value)}
                      className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-xs text-white focus:outline-none rounded"
                    >
                      <option>$500 - $1,000 / mo</option>
                      <option>$1,000 - $2,000 / mo</option>
                      <option>$2,000 - $5,000 / mo</option>
                      <option>$5,000 - $10,000 / mo</option>
                      <option>$10,000+ / mo (Ultra Premium scale)</option>
                    </select>
                  </div>

                  <button 
                    type="submit" 
                    disabled={aiGenerating}
                    className="w-full py-4 bg-gradient-to-r from-[#A37C24] via-[#D8B44F] to-[#A37C24] text-black font-semibold text-xs tracking-widest uppercase hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center gap-2 rounded cursor-pointer disabled:opacity-50"
                  >
                    {aiGenerating ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin text-black" />
                        Generating Your Blueprint...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-black" />
                        Generate Free Strategy Blueprint
                      </>
                    )}
                  </button>
                </form>

              </div>

              {/* Strategy Output Results Panel */}
              <div className="lg:col-span-7 h-full">
                <div className="w-full min-h-[500px] bg-[#02050E] border border-slate-800 rounded p-6 shadow-xl flex flex-col justify-between relative overflow-hidden">
                  
                  {/* Luxury file folder style visual representation card */}
                  <div className="absolute top-0 right-0 w-32 h-32 bg-[#D8B44F]/5 rounded-full blur-2xl pointer-events-none" />
                  
                  {/* Loader Area */}
                  {aiGenerating && (
                    <div className="flex-grow flex flex-col items-center justify-center p-8 animate-pulse">
                      <div className="w-16 h-16 bg-[#0B1537] border border-[#D8B44F]/40 rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(216,180,79,0.15)] mb-6">
                        <Sparkles className="w-8 h-8 text-[#D8B44F] animate-spin" />
                      </div>
                      <h4 className="font-display font-medium text-lg text-white mb-2 text-center">Formulating Executive Marketing Portfolio</h4>
                      <p className="text-xs text-[#D8B44F] tracking-widest uppercase font-mono animate-bounce text-center">{aiGenStep}</p>
                      
                      <div className="w-full max-w-sm bg-slate-900 h-1 rounded-full overflow-hidden mt-6">
                        <div className="bg-gold-gradient h-full rounded-full animate-infinite" style={{ width: '40%' }} />
                      </div>
                    </div>
                  )}

                  {/* Empty State Instructions */}
                  {!aiGenerating && !aiResult && !aiError && (
                    <div className="flex-grow flex flex-col items-center justify-center text-center p-8">
                      <div className="w-14 h-14 bg-slate-950 border border-[#D8B44F]/20 rounded-full flex items-center justify-center mb-6">
                        <Compass className="w-6 h-6 text-[#D8B44F] opacity-75" />
                      </div>
                      <h4 className="font-display font-medium text-lg text-slate-300 mb-2">Strategy Ledger: Blank</h4>
                      <p className="text-xs text-slate-500 max-w-sm leading-relaxed">
                        Input your business name and agency core targeting elements in the adjacent console to generate an elite, real-time campaign strategy blueprint.
                      </p>
                    </div>
                  )}

                  {/* Error State */}
                  {aiError && (
                    <div className="flex-grow flex flex-col items-center justify-center text-center p-8 text-red-400">
                      <X className="w-10 h-10 border border-red-500/30 rounded-full p-2 mb-4 bg-red-950/20" />
                      <h4 className="font-display font-medium text-md text-white mb-1">Execution System Halted</h4>
                      <p className="text-xs max-w-md">{aiError}</p>
                    </div>
                  )}

                  {/* strategy results display area */}
                  {aiResult && !aiGenerating && (
                    <div className="flex-grow flex flex-col justify-between">
                      <div className="flex justify-between items-center border-b border-[#D8B44F]/20 pb-4 mb-6">
                        <div>
                          <span className="text-[9px] font-mono uppercase tracking-[0.2em] text-[#D8B44F] bg-[#141F44] border border-[#D8B44F]/20 px-2 py-0.5 rounded">DOCUMENT CLASSIFICATION: ENTRUSTED</span>
                          <h3 className="font-display font-semibold text-lg text-white tracking-wide mt-2">{strategyBusiness} Portfolio Dossier</h3>
                        </div>
                        <CheckCircle2 className="w-6 h-6 text-[#D8B44F]" />
                      </div>

                      {/* Rendered markdown */}
                      <div className="max-h-[500px] overflow-y-auto pr-2 space-y-4 text-slate-200">
                        {renderStrategyMarkdown(aiResult)}
                      </div>

                      <div className="mt-8 border-t border-slate-800 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
                        <div className="text-left">
                          <p className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">Deploy Blueprint</p>
                          <p className="text-xs font-display font-medium text-[#D8B44F]">Our premium strategists are available for implementation.</p>
                        </div>
                        <button 
                          onClick={() => {
                            setConsultMsg(`Hello Growth Media Hub. I just generated an AI Strategy Blueprint for my business ${strategyBusiness} in the ${strategyIndustry} industry. I selected ${strategyChannel} platform focus and would like to schedule a session to deploy this!`);
                            setConsultBusiness(strategyBusiness);
                            scrollSection('contact');
                          }}
                          className="px-5 py-2.5 bg-[#121F46] hover:bg-[#1C2F6A] border border-[#D8B44F]/30 hover:border-[#D8B44F] text-xs text-white uppercase tracking-widest font-mono font-bold rounded flex items-center gap-1.5 cursor-pointer"
                        >
                          Deploy This Strategy <ArrowRight className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  )}

                </div>
              </div>

            </div>

          </div>
        </section>

        {/* ABOUT US SECTION */}
        <section id="about" className="py-24 px-6 lg:px-12 bg-gradient-to-b from-[#02050E] to-[#04091A]">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              
              {/* Image and trust points side */}
              <div className="relative">
                <div className="relative w-full aspect-video md:aspect-[4/3] rounded overflow-hidden shadow-2xl border border-[#D8B44F]/25 bg-blue-950">
                  {/* Decorative luxury abstract visuals representing target marketing agency layout */}
                  <div className="absolute inset-0 bg-[#060D25]/90 flex flex-col justify-center px-10">
                    <Crown className="w-12 h-12 text-[#D8B44F] mb-6 opacity-85" />
                    <h4 className="font-display font-semibold text-2xl text-white tracking-wide mb-3">ABOUT OUR FIRM</h4>
                    <p className="text-sm text-slate-400 leading-relaxed font-sans max-w-sm">
                      Growth Media Hub is a boutique performance-obsessed digital brand architect agency representing clients globally from our high-end workspaces.
                    </p>
                  </div>
                  <div className="absolute top-4 right-4 w-12 h-12 border-t border-r border-[#D8B44F] pointer-events-none" />
                  <div className="absolute bottom-4 left-4 w-12 h-12 border-b border-l border-[#D8B44F] pointer-events-none" />
                </div>

                {/* Overlap badge */}
                <div className="absolute bottom-[-20px] right-[20px] bg-[#070F2D] border border-[#D8B44F]/35 p-4 rounded hidden sm:block">
                  <div className="flex items-center gap-3">
                    <Award className="w-10 h-10 text-[#D8B44F]" />
                    <div>
                      <p className="text-xl font-display font-bold text-white tracking-tight">100%</p>
                      <p className="text-[10px] text-slate-400 uppercase tracking-widest font-mono">Bespoke Strategies</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Text Side */}
              <div>
                <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">ABOUT US</span>
                <h2 className="text-3xl sm:text-4xl font-display font-semibold text-white tracking-wide mb-6">
                  Transforming Brands Into Market Leaders
                </h2>

                <p className="text-slate-300 font-sans text-sm sm:text-base leading-relaxed mb-6">
                  At Growth Media Hub, we don&apos;t just manage social media—we build powerful digital brands. Our team specializes in creating premium marketing campaigns designed to increase visibility, generate qualified leads, and accelerate business growth. 
                </p>

                <p className="text-slate-300 font-sans text-sm sm:text-base leading-relaxed mb-8">
                  We combine creativity, innovation, and performance marketing to deliver measurable results that matter. We don&apos;t believe in vanity metrics; our compass points directly to client revenue pipeline scalability.
                </p>

                {/* Why Brands Choose Us section */}
                <div className="mb-8">
                  <h4 className="font-display font-semibold text-sm text-[#D8B44F] tracking-widest uppercase mb-4">Why Brands Choose Us</h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {[
                      "Premium Marketing Strategies",
                      "Data-Driven Growth Solutions",
                      "High-Converting Advertising Campaigns",
                      "Creative & Engaging Content",
                      "Transparent Reporting",
                      "Dedicated Expert Support"
                    ].map((why, i) => (
                      <div key={i} className="flex items-center gap-2.5">
                        <CheckCircle2 className="w-4 h-4 text-[#D8B44F]" />
                        <span className="text-xs text-slate-300 font-sans font-medium">{why}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Mission / Vision Cards */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 border-t border-[#D8B44F]/10 pt-8">
                  <div>
                    <h5 className="font-display font-semibold text-xs uppercase tracking-widest text-[#D8B44F] mb-1.5">Our Mission</h5>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      To empower businesses with world-class digital marketing solutions that drive growth, build authority, and create lasting success.
                    </p>
                  </div>
                  <div>
                    <h5 className="font-display font-semibold text-xs uppercase tracking-widest text-[#D8B44F] mb-1.5">Our Vision</h5>
                    <p className="text-slate-400 text-xs leading-relaxed">
                      To become a leading global digital marketing agency recognized for innovation, excellence, and measurable business results.
                    </p>
                  </div>
                </div>

              </div>

            </div>
          </div>
        </section>

        {/* PORTFOLIO SECTION */}
        <section id="portfolio" className="py-24 px-6 lg:px-12 bg-[#02050E]">
          <div className="max-w-7xl mx-auto">
            
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
              <div>
                <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">SELECT RECORD ARCHIVE</span>
                <h2 className="text-3xl sm:text-4xl font-display font-semibold text-white tracking-wide">
                  Our Campaigns Showcase
                </h2>
                <div className="w-16 h-0.5 bg-[#D8B44F] mt-3" />
              </div>
              <p className="text-slate-400 font-sans text-xs sm:text-sm max-w-md mt-4 md:mt-0 leading-relaxed">
                Explore verified campaign indicators. Each study outlines client challenge, targeted solution, and absolute scale result inside their channels.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {caseStudies.map((cs) => (
                <div 
                  key={cs.id}
                  className="bg-[#050D24]/60 border border-slate-800 text-left rounded overflow-hidden relative cursor-pointer group flex flex-col justify-between hover:border-[#D8B44F]/30 transition-colors"
                  onClick={() => setActiveCaseStudy(cs)}
                >
                  <div>
                    <div className="relative aspect-video w-full bg-slate-900 border-b border-slate-800 overflow-hidden">
                      <img 
                        src={cs.image} 
                        alt={cs.client}
                        className="object-cover w-full h-full group-hover:scale-105 transition-all duration-500"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-[#02050E]/80 opacity-0 group-hover:opacity-100 transition-all duration-300 flex items-center justify-center">
                        <span className="px-4 py-2 bg-gold-gradient text-black font-semibold text-[11px] uppercase tracking-widest shadow-md">
                          Review Case Ledger
                        </span>
                      </div>
                      
                      {/* Stats Floating Banner */}
                      <div className="absolute top-3 left-3 bg-[#02050E] border border-[#D8B44F]/40 px-3 py-1 text-slate-100 font-display font-bold text-xs tracking-wide">
                        {cs.stats}
                      </div>
                    </div>

                    <div className="p-5">
                      <p className="text-[10px] font-mono text-[#D8B44F] uppercase tracking-widest mb-1.5">{cs.category}</p>
                      <h4 className="font-display font-semibold text-lg text-white mb-2 leading-snug">{cs.client}</h4>
                      <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">{cs.challenge}</p>
                    </div>
                  </div>

                  <div className="px-5 pb-5 pt-3 border-t border-slate-800/60 flex items-center justify-between text-[11px] font-mono text-[#D8B44F] uppercase tracking-wider">
                    <span>{cs.metric}</span>
                    <span className="group-hover:translate-x-1.5 transition-transform flex items-center gap-1">Read Review <ArrowRight className="w-3.5 h-3.5" /></span>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* CASE STUDY MODAL OVERLAY */}
        <AnimatePresence>
          {activeCaseStudy && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setActiveCaseStudy(null)}
            >
              <motion.div 
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="bg-[#050D24] border border-[#D8B44F]/30 max-w-2xl w-full max-h-[85vh] overflow-y-auto rounded shadow-2xl relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button 
                  onClick={() => setActiveCaseStudy(null)}
                  className="absolute top-4 right-4 bg-slate-900 border border-slate-800 hover:border-[#D8B44F] text-slate-400 hover:text-[#D8B44F] p-1.5 rounded-full z-10 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>

                {/* Header Image banner */}
                <div className="relative h-48 sm:h-64 bg-slate-950">
                  <img src={activeCaseStudy.image} alt={activeCaseStudy.client} className="w-full h-full object-cover opacity-60" referrerPolicy="no-referrer" />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#050D24] via-transparent to-transparent" />
                  <div className="absolute bottom-5 left-6">
                    <span className="text-[10px] font-mono text-[#D8B44F] uppercase tracking-widest bg-slate-950 border border-[#D8B44F]/30 px-2 py-0.5">{activeCaseStudy.category}</span>
                    <h3 className="font-display font-bold text-2xl text-white mt-2 tracking-wide">{activeCaseStudy.client}</h3>
                  </div>
                </div>

                <div className="p-6 sm:p-8 space-y-6">
                  
                  {/* Stats Highlights Grid */}
                  <div className="grid grid-cols-2 gap-4 bg-slate-950/80 p-4 border border-slate-800">
                    <div>
                      <p className="text-[9px] uppercase font-mono text-slate-500 tracking-wider">Metrics Achieved</p>
                      <p className="text-xl font-display font-bold text-white text-gold-gradient tracking-tight">{activeCaseStudy.stats}</p>
                    </div>
                    <div>
                      <p className="text-[9px] uppercase font-mono text-slate-500 tracking-wider">Focus Target</p>
                      <p className="text-xl font-display font-bold text-white tracking-tight">{activeCaseStudy.metric}</p>
                    </div>
                  </div>

                  {/* Challenge */}
                  <div>
                    <h5 className="font-display font-semibold text-xs tracking-wider uppercase text-[#D8B44F] mb-1.5">The Challenge</h5>
                    <p className="text-slate-300 text-sm leading-relaxed">{activeCaseStudy.challenge}</p>
                  </div>

                  {/* Our Solution */}
                  <div>
                    <h5 className="font-display font-semibold text-xs tracking-wider uppercase text-[#D8B44F] mb-1.5">Our Implementation Strategy</h5>
                    <p className="text-slate-300 text-sm leading-relaxed">{activeCaseStudy.solution}</p>
                  </div>

                  {/* Result */}
                  <div>
                    <h5 className="font-display font-semibold text-xs tracking-wider uppercase text-[#D8B44F] mb-1.5">The Result</h5>
                    <p className="text-slate-300 text-sm leading-relaxed">{activeCaseStudy.result}</p>
                  </div>

                  <div className="flex justify-end gap-3 border-t border-slate-800 pt-6">
                    <button 
                      onClick={() => {
                        setConsultMsg(`Hello, I reviewed the Case Ledger for ${activeCaseStudy.client} generating ${activeCaseStudy.stats}. I would like to explore doing something similar for my business.`);
                        setActiveCaseStudy(null);
                        scrollSection('contact');
                      }}
                      className="px-5 py-2.5 bg-gold-gradient text-black hover:brightness-110 font-semibold text-xs uppercase tracking-widest"
                    >
                      I Want Similar results
                    </button>
                    <button 
                      onClick={() => setActiveCaseStudy(null)}
                      className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white border border-slate-800 text-xs uppercase tracking-widest font-mono"
                    >
                      Close
                    </button>
                  </div>

                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* TESTIMONIALS CAROUSEL SLIDER - INTERACTIVE HIGH CONVERTING SOCIAL PROOF */}
        <section id="testimonials" className="py-24 px-6 lg:px-12 bg-gradient-to-b from-[#02050E] to-[#040C24] border-t border-b border-[#D8B44F]/10">
          <div className="max-w-7xl mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">CLIENT TRIUMPH STORIES</span>
              <h2 className="text-2xl sm:text-4xl font-display font-semibold text-white tracking-wide">
                Professional Success Dossiers
              </h2>
              <div className="w-16 h-0.5 bg-[#D8B44F] mx-auto mt-4" />
            </div>

            {/* HIGH-FIDELITY SLIDER BOX */}
            <div className="relative max-w-4xl mx-auto">
              
              <div className="overflow-hidden bg-[#050D24]/40 border border-slate-800 rounded-xl p-8 sm:p-12 relative shadow-2xl">
                
                {/* Gold Quote Decorative Icon */}
                <div className="absolute top-6 right-8 text-[#D8B44F]/10 font-serif text-8xl pointer-events-none font-bold select-none leading-none">
                  “
                </div>

                <AnimatePresence mode="wait">
                  {[
                    {
                      quote: "Growth Media Hub took over our Meta ad strategy and literally revolutionized our e-commerce business. Devising custom video strategies took us from 2.2x to averaging 8.4x ROAS on scale. They are truly world-class architects.",
                      clientName: "Isabella Vance",
                      role: "Founder, Aura Premium Skincare",
                      stars: 5,
                      impact: "+340% Revenue Spark"
                    },
                    {
                      quote: "We spent thousands previously on generic lead agencies that returned recycled databases. Growth Media Hub set up customized property valuation funnels that capture verified client numbers instantly.",
                      clientName: "Harrison Croft",
                      role: "Managing Principal, Vertu Real Estate",
                      stars: 5,
                      impact: "+$2.1M High-Net Pipe"
                    },
                    {
                      quote: "The strategic authority positioning work they deployed for our B2B software is phenomenal. Our organic demonstrations and monthly search parameters generated steady streams of inbound pipeline.",
                      clientName: "Elena Rostova",
                      role: "VP of Growth, Vanguard SaaS",
                      stars: 5,
                      impact: "84% Automated demo hike"
                    }
                  ].map((t, idx) => {
                    if (idx !== activeTestimonial) return null;
                    return (
                      <motion.div 
                        key={idx}
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: -20 }}
                        transition={{ duration: 0.3 }}
                        className="text-left flex flex-col justify-between min-h-[220px]"
                      >
                        <div>
                          {/* Star Ratings */}
                          <div className="flex gap-1 mb-5">
                            {[...Array(t.stars)].map((_, i) => (
                              <Star key={i} className="w-4 h-4 fill-[#D8B44F] text-[#D8B44F]" />
                            ))}
                          </div>

                          {/* Testimonial Quote text */}
                          <p className="text-slate-300 text-sm sm:text-base md:text-lg italic leading-relaxed mb-6">
                            &ldquo;{t.quote}&rdquo;
                          </p>
                        </div>

                        {/* Client details & metrics validation */}
                        <div className="border-t border-slate-800/80 pt-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                          <div className="flex items-center gap-4">
                            <div className="w-12 h-12 rounded-full bg-blue-950 flex items-center justify-center border border-[#D8B44F]/30 uppercase tracking-widest font-display text-white text-xs font-bold shadow-inner">
                              {t.clientName.split(' ').map(n=>n[0]).join('')}
                            </div>
                            <div>
                              <h4 className="font-display font-semibold text-sm sm:text-base text-white leading-tight">{t.clientName}</h4>
                              <p className="text-[10px] sm:text-xs text-slate-500 uppercase tracking-wider mt-0.5 font-mono">{t.role}</p>
                            </div>
                          </div>

                          {/* Stat Highlight badge */}
                          <div className="px-3.5 py-1.5 bg-[#D8B44F]/10 border border-[#D8B44F]/30 rounded text-xs text-[#D8B44F] font-mono font-bold uppercase w-fit tracking-wider">
                            Verified Impact: {t.impact}
                          </div>
                        </div>
                      </motion.div>
                    );
                  })}
                </AnimatePresence>

              </div>

              {/* Slider Prev / Next Navigation Arrows */}
              <div className="flex justify-between items-center mt-8 px-2">
                <div className="flex gap-2">
                  <button 
                    onClick={() => setActiveTestimonial((prev) => (prev === 0 ? 2 : prev - 1))}
                    className="p-3 bg-[#050D24] border border-slate-800 hover:border-[#D8B44F]/40 rounded-full text-white hover:text-[#D8B44F] transition-all cursor-pointer active:scale-95"
                    aria-label="Previous Testimonial"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => setActiveTestimonial((prev) => (prev === 2 ? 0 : prev + 1))}
                    className="p-3 bg-[#050D24] border border-slate-800 hover:border-[#D8B44F]/40 rounded-full text-white hover:text-[#D8B44F] transition-all cursor-pointer active:scale-95"
                    aria-label="Next Testimonial"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Bullet Indicators */}
                <div className="flex gap-2">
                  {[0, 1, 2].map((bulletIdx) => (
                    <button 
                      key={bulletIdx}
                      onClick={() => setActiveTestimonial(bulletIdx)}
                      className={`w-2 h-2 rounded-full cursor-pointer transition-all ${bulletIdx === activeTestimonial ? 'bg-[#D8B44F] w-6' : 'bg-slate-700'}`}
                      aria-label={`Select Testimonial ${bulletIdx + 1}`}
                    />
                  ))}
                </div>
              </div>

            </div>

            {/* AGENCY TRUST BADGES SECTION - CREDIBILITY & TRUST INDICATORS */}
            <div className="mt-20 border-t border-slate-800/60 pt-16 max-w-5xl mx-auto">
              <h5 className="text-center font-mono text-[10px] uppercase text-slate-500 tracking-[0.25em] mb-10 font-bold">
                GROWTH MEDIA HUB CERTIFICATIONS & RECOGNITIONS
              </h5>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
                <div className="p-5 bg-[#050D24]/30 border border-slate-800/40 rounded flex flex-col items-center justify-center">
                  <Award className="w-8 h-8 text-[#D8B44F] mb-3" />
                  <span className="text-xs font-display font-bold text-white uppercase tracking-wider">Meta Business Partner</span>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">Certified Advanced Scaling</p>
                </div>
                <div className="p-5 bg-[#050D24]/30 border border-slate-800/40 rounded flex flex-col items-center justify-center">
                  <Sparkles className="w-8 h-8 text-[#D8B44F] mb-3" />
                  <span className="text-xs font-display font-bold text-white uppercase tracking-wider">Google Premier Partner</span>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">SEO & PPC Authority Hub</p>
                </div>
                <div className="p-5 bg-[#050D24]/30 border border-slate-800/40 rounded flex flex-col items-center justify-center">
                  <Crown className="w-8 h-8 text-[#D8B44F] mb-3" />
                  <span className="text-xs font-display font-bold text-white uppercase tracking-wider">ROAS Excellence Award</span>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">Average 8.4x Metrics Record</p>
                </div>
                <div className="p-5 bg-[#050D24]/30 border border-slate-800/40 rounded flex flex-col items-center justify-center">
                  <CheckCircle2 className="w-8 h-8 text-[#D8B44F] mb-3" />
                  <span className="text-xs font-display font-bold text-white uppercase tracking-wider">Verified Lead Generation</span>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">Compliant First-Party Data Capture</p>
                </div>
              </div>
            </div>

            {/* ELITE FAQ SEGMENT */}
            <div className="mt-24 max-w-3xl mx-auto">
              <div className="text-center mb-12">
                <span className="text-xs uppercase tracking-[0.25em] text-[#D8B44F] font-mono block mb-2 font-bold">CLEARING INQUIRIES</span>
                <h3 className="text-2xl sm:text-3xl font-display font-semibold text-white">Frequently Asked Questions</h3>
                <div className="w-12 h-0.5 bg-[#D8B44F] mx-auto mt-3" />
              </div>

              <div className="space-y-4">
                {[
                  {
                    q: "What typical results do you achieve for e-commerce brands?",
                    a: "We systematically scale e-commerce brands through customized, creative-first social media advertising on Meta and TikTok. Our historical accounts average an 8.4x ROAS by implementing conversion API configurations, high-value visual hooks, and dynamic creative templates to outpace rising ad costs."
                  },
                  {
                    q: "How does the AI Strategy Hub Blueprint work?",
                    a: "Our AI Strategy Hub uses advanced Gemini models paired with our proprietary agency research models. By specifying your industry, business name, and brand tone, it dynamically crafts a complete, ready-to-test growth roadmap encompassing ad copy hooks, layout optimizations, and campaign strategies."
                  },
                  {
                    q: "Does your agency lock clients into long-term contracts?",
                    a: "Absolutely not. We believe partnership should be driven by performance. We operate on flexible monthly agreements with standard performance milestones. Our retention average exceeds 94% simply because our strategic work consistently drives client revenue expansion."
                  },
                  {
                    q: "What is your typical onboarding process?",
                    a: "Upon scheduling your book free consultation slots, we perform a deep audit of your current ad networks, website conversions, and local competitors. Within 5 business days, we deploy custom assets, launch premium SMM creative campaigns, and establish baseline tracking systems."
                  },
                  {
                    q: "How do you ensure data compliance and privacy?",
                    a: "All direct calls, phone callbacks, and newsletter subscribers are stored securely in encrypted databases. We implement full Conversion APIs (CAPI) alongside Safari Intelligent Tracking Prevention (ITP) protections to ensure compliance with global data processing rules."
                  }
                ].map((faq, idx) => {
                  const isOpen = openedFaq === idx;
                  return (
                    <div 
                      key={idx} 
                      className="bg-[#050D24]/40 border border-slate-800 rounded-lg overflow-hidden transition-colors"
                    >
                      <button
                        onClick={() => setOpenedFaq(isOpen ? null : idx)}
                        className="w-full text-left px-5 py-4 sm:py-5 flex justify-between items-center text-white hover:text-[#D8B44F] transition-colors focus:outline-none"
                        style={{ minHeight: '48px' }}
                      >
                        <span className="font-display font-semibold text-sm sm:text-base pr-4 leading-snug">{faq.q}</span>
                        {isOpen ? (
                          <ChevronUp className="w-4 h-4 text-[#D8B44F] shrink-0" />
                        ) : (
                          <ChevronDown className="w-4 h-4 text-slate-500 shrink-0" />
                        )}
                      </button>

                      <AnimatePresence>
                        {isOpen && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            transition={{ duration: 0.25 }}
                            className="border-t border-slate-800/60 bg-[#02050E]/40"
                          >
                            <div className="p-5 text-sm text-slate-400 leading-relaxed font-sans">
                              {faq.a}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Micro summary */}
            <div className="mt-16 text-center bg-[#070F2D] border border-[#D8B44F]/10 p-4 max-w-xl mx-auto rounded">
              <p className="text-xs text-slate-400 font-sans leading-relaxed">
                Want to write your own success story? Explore our interactive <button onClick={() => scrollSection('ai-hub')} className="text-[#D8B44F] underline focus:outline-none hover:text-[#F3E7C4] font-bold">AI Growth Blueprint tool</button> or book a slots session directly below.
              </p>
            </div>

          </div>
        </section>

        {/* LOGICAL BLOG INFORMATIVE SEGMENT */}
        <section id="blog" className="py-24 px-6 lg:px-12 bg-[#02050E]">
          <div className="max-w-7xl mx-auto">
            
            <div className="flex flex-col md:flex-row md:items-end justify-between mb-16">
              <div>
                <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">INSIGHTS & RESOURCES</span>
                <h2 className="text-3xl sm:text-4xl font-display font-semibold text-white tracking-wide">
                  Agency Growth intelligence
                </h2>
                <div className="w-16 h-0.5 bg-[#D8B44F] mt-3" />
              </div>
              <p className="text-slate-400 font-sans text-xs sm:text-sm max-w-md mt-4 md:mt-0 leading-relaxed">
                Stay updated with leading modern paradigms inside paid ad networks, search clusters, and elite brand frameworks.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {blogPosts.map((post, idx) => (
                <div 
                  key={idx}
                  className="bg-[#050D24]/60 border border-slate-800 text-left rounded p-6 relative flex flex-col justify-between hover:border-[#D8B44F]/30 transition-colors cursor-pointer"
                  onClick={() => setActiveBlogPost(post)}
                >
                  <div>
                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 mb-3 uppercase tracking-wider">
                      <span className="text-[#D8B44F]">{post.category}</span>
                      <span>{post.date}</span>
                    </div>

                    <h4 className="font-display font-semibold text-lg text-white mb-3 hover:text-[#D8B44F] transition-colors leading-snug">
                      {post.title}
                    </h4>
                    <p className="text-slate-400 text-xs sm:text-sm leading-relaxed mb-6 line-clamp-3">
                      {post.excerpt}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs font-mono pt-4 border-t border-slate-800/80">
                    <span className="text-slate-500 flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {post.readTime}</span>
                    <span className="text-[#D8B44F] uppercase tracking-wider font-semibold group flex items-center gap-1">Read Post <ArrowRight className="w-3.5 h-3.5" /></span>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </section>

        {/* BLOG VIEW MODAL */}
        <AnimatePresence>
          {activeBlogPost && (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/85 backdrop-blur-sm z-50 flex items-center justify-center p-4"
              onClick={() => setActiveBlogPost(null)}
            >
              <motion.div 
                initial={{ scale: 0.95, y: 20 }}
                animate={{ scale: 1, y: 0 }}
                exit={{ scale: 0.95, y: 20 }}
                className="bg-[#050D24] border border-[#D8B44F]/30 max-w-xl w-full max-h-[85vh] overflow-y-auto p-6 sm:p-8 rounded shadow-2xl relative"
                onClick={(e) => e.stopPropagation()}
              >
                {/* Close Button */}
                <button 
                  onClick={() => setActiveBlogPost(null)}
                  className="absolute top-4 right-4 bg-slate-900 border border-slate-800 hover:border-[#D8B44F] text-slate-400 hover:text-[#D8B44F] p-1.5 rounded-full z-10 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>

                <div className="space-y-6 text-left">
                  <div className="flex items-center justify-between text-[10px] font-mono text-slate-500 border-b border-slate-800 pb-3">
                    <span className="text-[#D8B44F] uppercase tracking-widest">{activeBlogPost.category}</span>
                    <span>{activeBlogPost.date} • {activeBlogPost.readTime}</span>
                  </div>

                  <h3 className="font-display font-bold text-2xl text-white tracking-wide leading-tight mt-3">
                    {activeBlogPost.title}
                  </h3>

                  <div className="text-slate-300 text-sm sm:text-base leading-relaxed space-y-4">
                    <p className="italic font-sans text-slate-400 font-light border-l-2 border-[#D8B44F] pl-3 py-1">
                      {activeBlogPost.excerpt}
                    </p>
                    <p>{activeBlogPost.content}</p>
                    <p>At Growth Media Hub, we leverage these strict conversion guidelines everyday to build bespoke scaling paradigms for our clients. By focusing continuously on elite visual elements, first-party customer funnels, and rigorous conversion tracking, your brand establishes authority while scaling predictably.</p>
                  </div>

                  <div className="flex justify-between items-center border-t border-slate-800 pt-6">
                    <div className="text-[10px] uppercase font-mono text-slate-500">SHARE METRIC VIEW: INTERNAL STUDY</div>
                    <button 
                      onClick={() => {
                        setConsultPlatform("Social Media Marketing & Brand Strategy");
                        setActiveBlogPost(null);
                        scrollSection('contact');
                      }}
                      className="px-5 py-2.5 bg-gold-gradient text-black font-semibold text-xs uppercase tracking-widest"
                    >
                      Scale My Brand Now
                    </button>
                  </div>
                </div>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* BEFORE & AFTER TRIUMPH LABS */}
        <section className="py-24 px-6 lg:px-12 bg-[#02050E] border-t border-[#D8B44F]/10 relative overflow-hidden">
          <div className="absolute top-0 right-1/4 w-[350px] h-[350px] bg-[#D8B44F]/[0.02] rounded-full blur-[110px] pointer-events-none" />

          <div className="max-w-7xl mx-auto">
            
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">CONCRETE VALIDATED PROOF</span>
              <h2 className="text-2xl sm:text-4xl font-display font-semibold text-white tracking-wide">
                Brands Transformation Ledger
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-3">See how we transform failing customer acquisitions into optimized high-ROAS systems.</p>
              <div className="w-16 h-0.5 bg-[#D8B44F] mx-auto mt-4" />
            </div>

            {/* CASE SELECTOR TAB BUTTONS */}
            <div className="flex justify-center gap-4 mb-10">
              {[
                { name: "Aura Skincare Scale", idx: 0 },
                { name: "Vertu Real Estate Funnel", idx: 1 }
              ].map((tab) => (
                <button
                  key={tab.idx}
                  onClick={() => setActiveBeforeAfter(tab.idx)}
                  className={`px-5 py-2.5 text-xs font-mono font-bold uppercase tracking-widest transition-all rounded cursor-pointer ${
                    activeBeforeAfter === tab.idx 
                      ? "bg-[#D8B44F] text-black shadow-lg shadow-[#D8B44F]/15" 
                      : "bg-[#061130] text-slate-300 border border-slate-800 hover:border-[#D8B44F]/30"
                  }`}
                >
                  {tab.name}
                </button>
              ))}
            </div>

            {/* LEDGER CONTENT ROW */}
            <AnimatePresence mode="wait">
              {activeBeforeAfter === 0 ? (
                <motion.div
                  key="aura-before-after"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto"
                >
                  {/* Before Stats Card */}
                  <div className="bg-[#050D24]/20 border border-red-500/10 p-6 sm:p-10 rounded-xl relative">
                    <div className="absolute top-4 right-4 bg-red-500/10 border border-red-500/30 text-red-400 text-[9px] uppercase font-mono tracking-widest px-3 py-1 rounded font-bold">
                      Before Growth Media Hub
                    </div>
                    
                    <h3 className="font-display font-semibold text-lg text-white mb-6 border-b border-slate-900 pb-3">Stagnant E-commerce Funnel</h3>
                    
                    <div className="space-y-4 text-xs font-sans text-slate-400">
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Average Meta Ad ROAS:</span>
                        <span className="text-red-400 font-bold font-mono">2.2x Stagnation</span>
                      </div>
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Ad Creative Fatigue:</span>
                        <span className="text-red-400 font-bold">New ads required weekly with zero hook metrics</span>
                      </div>
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Customer Acquisition Cost:</span>
                        <span className="text-red-400 font-bold">$34.00 Average CAC</span>
                      </div>
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Meta Pixel Setup:</span>
                        <span className="text-red-400 font-bold">No custom events, leaky tracking infrastructure</span>
                      </div>
                    </div>
                  </div>

                  {/* After Stats Card */}
                  <div className="bg-[#050D24]/40 border border-[#D8B44F]/30 p-6 sm:p-10 rounded-xl relative shadow-2xl">
                    <div className="absolute top-4 right-4 bg-green-500/10 border border-green-500/30 text-green-400 text-[9px] uppercase font-mono tracking-widest px-3 py-1 rounded font-bold animate-pulse">
                      ● Active Strategic Triumph
                    </div>
                    
                    <h3 className="font-display font-semibold text-lg text-[#D8B44F] mb-6 border-b border-[#D8B44F]/10 pb-3">High-Octane ROAS Engine</h3>
                    
                    <div className="space-y-4 text-xs font-sans text-slate-200">
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Average Meta Ad ROAS:</span>
                        <span className="text-green-400 font-bold text-sm font-mono">8.4x Verified Peak</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Video Hook Content:</span>
                        <span className="text-green-400 font-bold">Premium lifestyle hooks boosting conversion metrics by 42%</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Customer Acquisition Cost:</span>
                        <span className="text-green-400 font-bold">$14.00 (60% CAC reduction)</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Advanced Meta SDK Routing:</span>
                        <span className="text-green-400 font-bold">Meticulous CAPI Integration tracking 99% conversion</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="vertu-before-after"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -15 }}
                  className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto"
                >
                  {/* Before Real Estate Card */}
                  <div className="bg-[#050D24]/20 border border-red-500/10 p-6 sm:p-10 rounded-xl relative">
                    <div className="absolute top-4 right-4 bg-red-500/10 border border-red-500/30 text-red-400 text-[9px] uppercase font-mono tracking-widest px-3 py-1 rounded font-bold">
                      Before Growth Media Hub
                    </div>
                    
                    <h3 className="font-display font-semibold text-lg text-white mb-6 border-b border-slate-900 pb-3">Recycled Database stagnation</h3>
                    
                    <div className="space-y-4 text-xs font-sans text-slate-400">
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Qualified Monthly Leads:</span>
                        <span className="text-red-400 font-bold font-mono">12-15 generic signups</span>
                      </div>
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Contact Quality Rate:</span>
                        <span className="text-red-400 font-bold">Unverified phone numbers, silent callbacks</span>
                      </div>
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">Booking Pipeline:</span>
                        <span className="text-red-400 font-bold">Manual tracking leaks with sales team fatigue</span>
                      </div>
                      <div className="flex justify-between items-center bg-black/30 p-3 rounded">
                        <span className="font-mono">High-Net-Worth Capture:</span>
                        <span className="text-red-400 font-bold">Broad generic targeting showing low-budget leads</span>
                      </div>
                    </div>
                  </div>

                  {/* After Real Estate Card */}
                  <div className="bg-[#050D24]/40 border border-[#D8B44F]/30 p-6 sm:p-10 rounded-xl relative shadow-2xl">
                    <div className="absolute top-4 right-4 bg-green-500/10 border border-green-500/30 text-green-400 text-[9px] uppercase font-mono tracking-widest px-3 py-1 rounded font-bold animate-pulse">
                      ● Active Strategic Triumph
                    </div>
                    
                    <h3 className="font-display font-semibold text-lg text-[#D8B44F] mb-6 border-b border-[#D8B44F]/10 pb-3">Automated HNW Inbound Pipeline</h3>
                    
                    <div className="space-y-4 text-xs font-sans text-slate-200">
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Qualified Monthly Leads:</span>
                        <span className="text-green-400 font-bold text-sm font-mono">140+ luxury investor profiles</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Verification System:</span>
                        <span className="text-green-400 font-bold">Instant OTP WhatsApp/SMS numbers check integration</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Private Booking Funnel:</span>
                        <span className="text-green-400 font-bold font-mono">340+ validated direct booking sessions scheduled</span>
                      </div>
                      <div className="flex justify-between items-center bg-[#071333] p-3 rounded border border-[#D8B44F]/15">
                        <span className="font-mono text-[#D8B44F]">Asset Volume Earned:</span>
                        <span className="text-green-400 font-bold">+$2.1M HNW real estate sales pipeline</span>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

          </div>
        </section>

        {/* PREMIUM FAQ SECTION */}
        <section className="py-24 px-6 lg:px-12 bg-gradient-to-b from-[#02050E] to-[#040C24] border-t border-[#D8B44F]/10">
          <div className="max-w-4xl mx-auto">
            
            <div className="text-center max-w-2xl mx-auto mb-16">
              <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">TRANSPARENT ANSWERS</span>
              <h2 className="text-2xl sm:text-4xl font-display font-semibold text-white tracking-wide">
                Frequently Answered Intel
              </h2>
              <p className="text-slate-400 text-xs sm:text-sm mt-3">Shedding absolute clarity on how we integrate with your team to scale revenue.</p>
              <div className="w-16 h-0.5 bg-[#D8B44F] mx-auto mt-4" />
            </div>

            {/* ACCORDION WRAPPER */}
            <div className="space-y-4">
              {[
                {
                  q: "What ad budget brackets does Growth Media Hub manage?",
                  a: "We manage ad budgets from $2,000 / month up to high-intensity allocations exceeding $50,000 / month. Our campaigns are built with meticulous unit-economic metrics, meaning tracking ROAS and actual buyer actions is always verified."
                },
                {
                  q: "How fast can we expect concrete, verified leads?",
                  a: "For immediate, high-converting platforms (Meta Ads & Facebook Advertising), campaigns go live within 5 to 7 business days following strategy sign-off. We typically see high-quality lead actions surfacing within the first 48 hours of initial deployment."
                },
                {
                  q: "Do we receive transparent live dashboards?",
                  a: "Absolutely. We are fully transparent. You receive a bespoke real-time client dash compiling every key attribution metric—leads volume, click-through-rates, actual sales ROAS, and total spend — synced straight from Meta and Google APIs."
                },
                {
                  q: "How does the AI Strategy Blueprint Hub generate its results?",
                  a: "Our free strategy hub leverages server-side Google Gemini integrations to analyze your specified industry, brand tone, and budget. It formulates actual copy guidelines, creative recommendations, and allocation tactics custom-fitted to your goals."
                },
                {
                  q: "Is there a long-term contract requirement?",
                  a: "No. We believe in performance-driven retention. Our partnerships operate on a month-to-month retainer format. We keep your business and brand through actual, verified numbers and transparent data rather than binding long-term templates."
                }
              ].map((faq, idx) => {
                const isOpen = openedFaq === idx;
                return (
                  <div 
                    key={idx}
                    className="border border-slate-800 hover:border-[#D8B44F]/25 bg-[#050D24]/30 rounded-lg overflow-hidden transition-all duration-300"
                  >
                    <button
                      onClick={() => setOpenedFaq(isOpen ? null : idx)}
                      className="w-full text-left p-5 sm:p-6 bg-transparent flex justify-between items-center text-white focus:outline-none cursor-pointer"
                    >
                      <span className="font-display font-medium text-sm sm:text-base pr-4">{faq.q}</span>
                      <span className={`transition-transform duration-300 ${isOpen ? 'rotate-180 text-[#D8B44F]' : 'text-slate-500'}`}>
                        <ChevronDown className="w-5 h-5" />
                      </span>
                    </button>

                    <AnimatePresence initial={false}>
                      {isOpen && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: "auto", opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.25 }}
                          className="overflow-hidden"
                        >
                          <div className="p-5 sm:p-6 pt-0 border-t border-slate-800/60 text-xs sm:text-sm text-slate-400 leading-relaxed font-sans">
                            {faq.a}
                          </div>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                );
              })}
            </div>

          </div>
        </section>

        {/* HIGH-CONVERTING CONTACT OR CONSULTATION BOOKING */}
        <section id="contact" className="py-24 px-6 lg:px-12 bg-gradient-to-b from-[#02050E] to-[#010309] border-t border-[#D8B44F]/10 relative">
          <div className="max-w-7xl mx-auto">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
              
              {/* Context Details Side */}
              <div className="lg:col-span-5 text-left">
                <span className="text-xs uppercase tracking-[0.3em] text-[#D8B44F] font-mono font-bold block mb-3">SCHEDULE RESERVATION</span>
                <h2 className="text-3xl sm:text-4xl font-display font-semibold text-white tracking-tight leading-tight mb-4">
                  Ready To Grow Faster?
                </h2>
                
                <p className="text-slate-300 font-sans text-sm sm:text-base leading-relaxed mb-8">
                  Partner with Growth Media Hub and unlock the full potential of your brand with premium digital marketing services. Reserve an elite consultant walkthrough slot directly today.
                </p>

                {/* Specific Contacts Grid */}
                <div className="space-y-6">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-900 border border-slate-800 flex items-center justify-center rounded">
                      <Mail className="w-5 h-5 text-[#D8B44F]" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">Direct Inquiry Email</p>
                      <a href="mailto:consult@growthmediahub.com" className="text-sm font-sans font-medium text-slate-200 hover:text-[#D8B44F] transition-colors">
                        consult@growthmediahub.com
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-900 border border-slate-800 flex items-center justify-center rounded">
                      <MessageSquare className="w-5 h-5 text-green-400" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">Fast-track WhatsApp Client Care</p>
                      {/* WhatsApp Business Action Trigger */}
                      <a 
                        href="https://wa.me/15550199?text=Hello%20Growth%20Media%20Hub.%20I%20am%20interested%20in%20high-converting%20social%20media%20marketing%20services.%20Can%20we%20schedule%20a%20private%20consultation?" 
                        target="_blank" 
                        rel="noreferrer"
                        className="text-sm font-sans font-medium text-green-400 hover:underline flex items-center gap-1"
                      >
                        Launch Direct Chat <ArrowRight className="w-3.5 h-3.5" />
                      </a>
                    </div>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-900 border border-slate-800 flex items-center justify-center rounded">
                      <MapPin className="w-5 h-5 text-[#D8B44F]" />
                    </div>
                    <div>
                      <p className="text-[10px] uppercase font-mono text-slate-500 tracking-wider">HQ Headquarters Location</p>
                      <p className="text-sm font-sans font-medium text-slate-200">
                        Level 42, Marina Tower, Dubai, UAE
                      </p>
                    </div>
                  </div>
                </div>

                {/* Secure Trust Notice */}
                <div className="mt-12 p-4 bg-[#050D24]/50 border-l-2 border-[#D8B44F] text-xs text-slate-400 max-w-sm rounded">
                  All enterprise inputs are guarded by premium non-disclosure parameters and stored under strict privacy vaults.
                </div>
              </div>

              {/* Secure Registration form client container */}
              <div className="lg:col-span-7 w-full leading-relaxed">
                <div className="bg-[#050F32]/60 border border-[#D8B44F]/20 p-6 sm:p-8 rounded shadow-2xl relative overflow-hidden">
                  <div className="absolute top-0 right-0 w-24 h-24 bg-blue-900/10 rounded-full blur-xl pointer-events-none" />
                  
                  <h3 className="font-display font-semibold text-lg text-white tracking-wide mb-6">Reserve Strategic Session</h3>

                  <AnimatePresence>
                    {successMsg && (
                      <motion.div 
                        initial={{ opacity: 0, y: 15 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: 15 }}
                        className="p-5 bg-green-500/10 border border-green-500/20 text-green-400 text-sm leading-relaxed mb-6 space-y-3 rounded text-left"
                      >
                        <p className="font-bold">✓ Consultation Pre-Reserved Successfully!</p>
                        <p className="text-xs text-slate-300">{successMsg}</p>
                        <div className="pt-2">
                          <a 
                            href={`https://wa.me/15550199?text=Hello%20Growth%20Media%20Hub.%20This%20is%20${encodeURIComponent(consultName || "Representative")}%20from%20${encodeURIComponent(consultBusiness || "my%20business")}.%20I%20have%20pre-reserved%20my%20session%20via%20your%20website.%20When%20can%20we%20begin?`}
                            target="_blank" 
                            rel="noreferrer"
                            className="inline-flex items-center gap-2 px-4 py-2 bg-green-500 hover:bg-green-600 text-black text-xs font-bold font-mono tracking-widest uppercase rounded shadow transition-all focus:outline-none"
                          >
                            <MessageSquare className="w-3.5 h-3.5 fill-black text-black" /> Click to Verify on WhatsApp Now
                          </a>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>

                  <form onSubmit={handleConsultSubmit} className="space-y-4 text-left">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Your Full Name *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Isabella Mercer"
                          value={consultName}
                          onChange={(e) => setConsultName(e.target.value)}
                          className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none rounded"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-[10px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Corporate Email *</label>
                        <input 
                          type="email" 
                          required
                          placeholder="e.g. ceo@auracosmetics.com"
                          value={consultEmail}
                          onChange={(e) => setConsultEmail(e.target.value)}
                          className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none rounded"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[10px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Contact Phone (Whatsapp Preferred) *</label>
                        <input 
                          type="tel" 
                          required
                          placeholder="e.g. +1 555 0199"
                          value={consultPhone}
                          onChange={(e) => setConsultPhone(e.target.value)}
                          className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none rounded"
                        />
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Business Name *</label>
                        <input 
                          type="text" 
                          required
                          placeholder="e.g. Aura Aesthetics, Vertu Corp"
                          value={consultBusiness}
                          onChange={(e) => setConsultBusiness(e.target.value)}
                          className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none rounded"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Target Scaling Placement</label>
                      <select 
                        value={consultPlatform}
                        onChange={(e) => setConsultPlatform(e.target.value)}
                        className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-xs text-white focus:outline-none rounded"
                      >
                        <option>Meta Ads (Facebook & Instagram Advertising)</option>
                        <option>Social Media Marketing & Brand Strategy</option>
                        <option>Content Strategy, Creation & Video Ads</option>
                        <option>Lead Generation Funnels & Automation</option>
                        <option>Google Ads & SEO Optimization</option>
                        <option>Global Scale Strategy (All Platform Suite)</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-[10px] uppercase tracking-wider font-mono text-[#D8B44F] mb-1.5 font-bold">Additional context / Scaling hurdles</label>
                      <textarea 
                        rows={3}
                        placeholder="e.g. Currently spending $5k on ads with low returns. Looking for premium aesthetic overhaul..."
                        value={consultMsg}
                        onChange={(e) => setConsultMsg(e.target.value)}
                        className="w-full bg-[#02050E] border border-slate-800 focus:border-[#D8B44F] p-3 text-sm text-white focus:outline-none rounded placeholder-slate-600"
                      />
                    </div>

                    <button 
                      type="submit" 
                      disabled={formLoading}
                      className="w-full py-4 bg-gradient-to-r from-[#A37C24] via-[#D8B44F] to-[#A37C24] text-black font-semibold text-xs tracking-widest uppercase hover:brightness-110 active:scale-[0.99] transition-all flex items-center justify-center gap-2 rounded cursor-pointer disabled:opacity-50"
                    >
                      {formLoading ? (
                        <>
                          <Loader2 className="w-4 h-4 animate-spin text-black" />
                          Scheduling Slot...
                        </>
                      ) : (
                        <>
                          <Send className="w-3.5 h-3.5 text-black" />
                          Reserve Session
                        </>
                      )}
                    </button>
                  </form>

                </div>
              </div>

            </div>
          </div>
        </section>

      </main>

      {/* LUXURY FOOTER */}
      <footer className="bg-[#02050E] border-t border-[#D8B44F]/10 pt-16 pb-8 px-6 lg:px-12 text-slate-400">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-16 text-left">
          
          {/* Logo & Narrative with custom high-fidelity GM branding */}
          <div className="space-y-4 text-left">
            <div className="flex items-center gap-3.5">
              <div className="relative flex items-center justify-center w-12 h-12 bg-[#010515] border border-[#D8B44F]/30 rounded shadow-md">
                <GMBrandLogo className="w-full h-full" dark={true} />
              </div>
              <div className="flex flex-col">
                <h4 className="font-display font-bold text-md leading-none text-white tracking-wider uppercase">
                  GROWTH <span className="text-gold-gradient">MEDIA</span>
                </h4>
                <div className="flex items-center gap-1 mt-1">
                  <span className="h-[1px] w-2 bg-[#D8B44F]/40"></span>
                  <span className="text-[8px] uppercase tracking-[0.25em] text-[#D8B44F] font-mono leading-none">Hub</span>
                  <span className="h-[1px] w-2 bg-[#D8B44F]/40"></span>
                </div>
              </div>
            </div>
            
            <p className="text-xs leading-relaxed max-w-sm">
              Growth Media Hub is a results-driven digital marketing agency helping businesses increase visibility, attract customers, and grow revenue through innovative marketing solutions.
            </p>

            {/* Social Icons */}
            <div className="flex gap-4 pt-2">
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="text-slate-500 hover:text-[#D8B44F] transition-colors"><Instagram className="w-4 h-4" /></a>
              <a href="https://facebook.com" target="_blank" rel="noreferrer" className="text-slate-500 hover:text-[#D8B44F] transition-colors"><Facebook className="w-4 h-4" /></a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="text-slate-500 hover:text-[#D8B44F] transition-colors"><Linkedin className="w-4 h-4" /></a>
            </div>
          </div>

          {/* Core Services Links */}
          <div>
            <h5 className="font-display font-semibold text-xs text-white uppercase tracking-wider mb-4 border-l-2 border-[#D8B44F]/80 pl-3">CORE SERVICES</h5>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => { setStrategyChannel("Social Media Marketing"); scrollSection('ai-hub'); }} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Social Media Marketing</button></li>
              <li><button onClick={() => { setStrategyChannel("Facebook Ads Leads"); scrollSection('ai-hub'); }} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Facebook Advertising</button></li>
              <li><button onClick={() => { setStrategyChannel("Instagram Mastery"); scrollSection('ai-hub'); }} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Instagram Marketing</button></li>
              <li><button onClick={() => { setStrategyChannel("DTC Meta Conversions"); scrollSection('ai-hub'); }} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Content Creation</button></li>
              <li><button onClick={() => { setStrategyChannel("SEO Topical Domination"); scrollSection('ai-hub'); }} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">SEO Optimization</button></li>
              <li><button onClick={() => { setStrategyChannel("TikTok Short Form Scale"); scrollSection('ai-hub'); }} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left text-xs">Lead Gen Campaigns</button></li>
            </ul>
          </div>

          {/* Quick Navigation Links */}
          <div>
            <h5 className="font-display font-semibold text-xs text-white uppercase tracking-wider mb-4 border-l-2 border-[#D8B44F]/80 pl-3">QUICK LINKS</h5>
            <ul className="space-y-2 text-xs">
              <li><button onClick={() => scrollSection('hero')} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Home Base</button></li>
              <li><button onClick={() => scrollSection('about')} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Our Narrative</button></li>
              <li><button onClick={() => scrollSection('services')} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Capabilities</button></li>
              <li><button onClick={() => scrollSection('portfolio')} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Successful records</button></li>
              <li><button onClick={() => scrollSection('testimonials')} className="hover:text-[#D8B44F] transition-colors focus:outline-none text-left">Dossiers</button></li>
              <li><button onClick={() => scrollSection('ai-hub')} className="hover:text-[#D8B44F] text-[#D8B44F] transition-colors font-bold focus:outline-none text-left">AI Strategy Blueprint</button></li>
            </ul>
          </div>

          {/* Quick Newsletter sign-up */}
          <div className="space-y-4">
            <h5 className="font-display font-semibold text-xs text-white uppercase tracking-wider border-l-2 border-[#D8B44F]/80 pl-3">ALERTS SUITE</h5>
            <p className="text-xs">Subscribe to receive first-look campaign structures from our Chief Growth Matrix.</p>
            <div className="flex">
              <input type="email" placeholder="consult@corporate.com" className="bg-[#02050E] border border-slate-800 p-2 text-xs focus:outline-none rounded-l w-full text-white" />
              <button 
                onClick={() => alert("Successfully authenticated subscription slot.")}
                className="bg-gold-gradient p-2 text-black font-bold uppercase text-[10px] rounded-r cursor-pointer focus:outline-none"
              >
                Join
              </button>
            </div>
          </div>

        </div>

        {/* Copy Bar */}
        <div className="border-t border-[#D8B44F]/10 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-xs">© 2026 Growth Media Hub. All Rights Reserved.</p>
          <div className="flex gap-4 text-[10px] uppercase font-mono tracking-wider">
            <span className="hover:text-[#D8B44F] cursor-pointer">Security Ledger</span>
            <span>•</span>
            <span className="hover:text-[#D8B44F] cursor-pointer">Privacy Protocol</span>
          </div>
        </div>
      </footer>

      {/* FLOATING ACTION UTILITIES (WhatsApp & Scroll-To-Top) */}
      
      {/* 1. FLOATING WHATSAPP CLIENT CARE WITH RESPONSIVE TOOLTIP */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-3 pointer-events-none">
        
        {/* Animated Greeting Message */}
        <AnimatePresence>
          {showWhatsappTooltip && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 10 }}
              className="bg-[#050D24] border border-[#D8B44F]/30 p-3 rounded-lg shadow-2xl max-w-xs text-left relative pointer-events-auto"
            >
              <button 
                onClick={() => setShowWhatsappTooltip(false)}
                className="absolute top-1 right-1 text-slate-500 hover:text-[#D8B44F] transition-colors p-0.5 focus:outline-none"
                aria-label="Close Whatsapp Tip"
              >
                <X className="w-3 h-3" />
              </button>
              <p className="text-[10px] font-mono uppercase text-[#D8B44F] tracking-wide font-bold mb-1">Chief Executive Concierge</p>
              <p className="text-xs text-slate-200 leading-normal pr-4">&ldquo;Hey there! Need a fast strategy walkthrough? Chat with our growth leads instantly.&rdquo;</p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* WhatsApp Button */}
        <div className="pointer-events-auto relative">
          {/* Pulsing Backwaves to draw attention */}
          <span className="absolute inset-0 bg-green-500/20 rounded-full animate-ping pointer-events-none" />
          
          <a 
            href="https://wa.me/15550199?text=Hello%20Growth%20Media%20Hub.%20I%20am%20interested%20in%20high-converting%20social%20media%20marketing%20services.%20Can%20we%20schedule%20a%20private%20consultation?" 
            target="_blank" 
            rel="noreferrer"
            className="w-14 h-14 bg-green-500 hover:bg-green-600 border border-green-400 text-white rounded-full flex items-center justify-center shadow-[0_0_20px_rgba(34,197,94,0.4)] transition-all transform hover:scale-110 active:scale-95"
            aria-label="Chat on WhatsApp"
            id="floating-whatsapp-btn"
          >
            {/* Custom high-contrast bubble logo */}
            <MessageSquare className="w-6 h-6 fill-white text-green-600" />
            
            {/* Visual indicator badge */}
            <span className="absolute -top-1 -right-1 bg-[#D8B44F] text-black font-bold font-mono text-[9px] w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#02050E]">
              1
            </span>
          </a>
        </div>
      </div>

      {/* 2. ELEGANT SCROLL TO TOP GOLD BUTTON */}
      <AnimatePresence>
        {showScrollTop && (
          <motion.button
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
            className="fixed bottom-6 left-6 z-50 p-3.5 bg-[#050D24]/90 border border-[#D8B44F]/30 hover:border-[#D8B44F] text-[#D8B44F] rounded-full shadow-2xl transition-all transform active:scale-95 hover:bg-[#0E1E4E] cursor-pointer"
            aria-label="Scroll to Top"
            id="scroll-to-top-btn"
          >
            <ArrowUp className="w-5 h-5 animate-pulse" />
          </motion.button>
        )}
      </AnimatePresence>
    </div>
  );
}
