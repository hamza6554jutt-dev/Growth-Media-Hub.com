import { GoogleGenAI } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize Gemini client as per guidelines
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { businessName, industry, budget, primaryChannel, brandTone } = await req.json();

    if (!businessName || !industry || !budget || !primaryChannel || !brandTone) {
      return NextResponse.json(
        { error: "Please fill in all requested fields to generate your custom strategy." },
        { status: 400 }
      );
    }

    const systemInstruction = 
      "You are the Chief Growth Strategist at Growth Media Hub, a top-tier luxury marketing agency representing elite global brands. " +
      "You write with supreme confidence, marketing intelligence, and executive premium authority. " +
      "Never sound generic; provide highly tactical, modern, and detailed marketing recommendations.";

    const prompt = `
Generate a bespoke social media and digital marketing blueprint for:
- Client Name: ${businessName}
- Industry / Niche: ${industry}
- Dedicated Ad Budget: ${budget}
- Primary Channel focus: ${primaryChannel}
- Desired Brand Positioning Theme: ${brandTone}

Structure the marketing strategy into these exact five gold standard luxury sections. Be very thorough, sophisticated, and analytical. Use elegant, high-impact copywriting.

### 1. Brand Authority & Creative Distinction
Provide a premium brand perception analysis. Detail how we will restructure their design guidelines, typography, color harmony, and visual assets to command premium rates and stand out as standard-setters.

### 2. Tailored Funnel Architecture
Build a bespoke 3-stage customer journey (TOFU, MOFU, BOFU) tailored for ${primaryChannel}. Detail specific ad formats, target personas, and dynamic creative hooks they should deploy today.

### 3. Campaign & Copy Blueprint
Provide 3 highly specific high-converting campaign concepts, including:
- Creative Hook (visual prompt)
- Copy Hook (under written angle)
- Direct Call-to-Action

### 4. Organic Social Domination
Outline an organic social amplification formula. Suggest detailed episodic content series ideas that build a massive, passionate community around their brand without relying solely on paid ads.

### 5. Expected Performance Metrics & Scale Blueprint
Break down key KPIs they should measure based on their ${budget} budget. Add a professional, realistic performance calculation outlining estimated impression range, CTR, CPL, and ROAS parameters. End with a premium call to action to contact the Growth Media Hub expert team to deploy this blueprint.
    `;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    return NextResponse.json({ text: response.text });
  } catch (error: any) {
    console.error("Gemini strategy generation failed:", error);
    return NextResponse.json(
      { error: "Luxury strategy engine is temporary offline. Please contact our strategists directly at consult@growthmediahub.com" },
      { status: 500 }
    );
  }
}
